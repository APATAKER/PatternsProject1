# Patterns Project 1

## In Project

- Implemented Abstract Factory for Creating Diffrent Game Objects, Example: one gameObjects is affected by phiysics and other object is not
 
- Implemented Builder Factory for Creating Diffrent Types of Game Object, Example: Gameobjects are charcterized into diffrent classes of Pirates(leader,ranged,melee)

- Implemented Mediator and PIMPL on Lights

- Implemented Singleton on VAOManager, only one instance of the object is used.

#Contributor
Dhilip Raja Nagarajan 