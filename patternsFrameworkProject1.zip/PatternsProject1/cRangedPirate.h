#ifndef _cRangedPirate_HG
#define _cRangedPirate_HG

class cRangedPirate
{
public:
	cRangedPirate();
	~cRangedPirate();

	//void setGameObject(iObject* pTheGO);
	//iObject* getGameObject();

private:
	float size;

	//iObject* pTheGO;

};
#endif // !_cRangedPirate_HG
