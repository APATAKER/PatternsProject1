#ifndef _cLeaderPirate_HG
#define _cLeaderPirate_HG


class cLeaderPirate
{
public:
	cLeaderPirate();
	~cLeaderPirate();

	//void setGameObject(iObject* pTheGO);
	//iObject* getGameObject();


private:
	float size;


};
#endif // !_cLeaderPirate_HG
