#include"cRangedPirate.h"

cRangedPirate::cRangedPirate()
{
	this->size = 0.5;
}

cRangedPirate::~cRangedPirate()
{
}
//
//void cRangedPirate::setGameObject(iObject* pTheGO)
//{
//	this->pTheGO = pTheGO;
//	this->pTheGO->setScale(this->size);
//
//	return;
//}
//iObject* cRangedPirate::getGameObject()
//{
//	return this->pTheGO;
//}

