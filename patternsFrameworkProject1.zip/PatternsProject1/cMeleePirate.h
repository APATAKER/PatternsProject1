#ifndef _cMeleePirate_HG_
#define _cMeleePirate_HG_


class cMeleePirate
{
public:
	cMeleePirate();
	~cMeleePirate();

	/*void setGameObject(iObject* pTheGO);
	iObject* getGameObject();*/


private:
	float size;
	

};
#endif // !_cMeleePirate_HG_
