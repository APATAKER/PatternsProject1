#include"cLeaderPirate.h"

cLeaderPirate::cLeaderPirate()
{
	this->size = 2.0f;
}

cLeaderPirate::~cLeaderPirate()
{
}

//void cLeaderPirate::setGameObject(iObject* pTheGO)
//{
//	this->pTheGO = pTheGO;
//	this->pTheGO->setScale(this->size);
//
//	return;
//}
//iObject* cLeaderPirate::getGameObject()
//{
//	return this->pTheGO;
//}

