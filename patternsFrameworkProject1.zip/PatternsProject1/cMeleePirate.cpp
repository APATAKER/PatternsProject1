#include"cMeleePirate.h"

cMeleePirate::cMeleePirate()
{
	this->size = 1.0f;
}

cMeleePirate::~cMeleePirate()
{
}

//void cMeleePirate::setGameObject(iObject* pTheGO)
//{
//	this->pTheGO = pTheGO;
//	this->pTheGO->setScale(this->size);
//
//	return;
//}
//iObject* cMeleePirate::getGameObject()
//{
//	return this->pTheGO;
//}
