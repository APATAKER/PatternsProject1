#ifndef _openGLStuff_HG_
#define _openGLStuff_HG_
#include"ProjectControlsAndCallback.h"

GLFWwindow* creatOpenGL(GLFWwindow* win);


#endif // !_openGLStuff_HG_

