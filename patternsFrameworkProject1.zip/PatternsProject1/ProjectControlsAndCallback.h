#ifndef _ProjectControlsAndCallback_HG_
#define _ProjectControlsAndCallback_HG_

#include"commonHeaders.h"





void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);

void error_callback(int error, const char* description);
void updateFile();

#endif