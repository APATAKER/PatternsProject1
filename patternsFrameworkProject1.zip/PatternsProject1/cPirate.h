#ifndef _cPirate_HG_
#define _cPirate_HG_


class cPirate
{
public:
	cPirate();
	~cPirate();

	//void setGameObject(iObject* pTheGO);
	//iObject* getGameObject();


private:
	float size;
	

};


#endif // !_cPirate_HG_
