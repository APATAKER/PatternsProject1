#include "cLightManager.h"

cLightManager::cLightManager()
{
}

cLightManager::~cLightManager()
{
}

//void getStringForPassingUniformName()
//{
//	std::string inital = "theLights[";
//	std::string endSqBrkt = "].";
//	int i = 0;
//	while (i < 7)
//	{
//		for (int s = 0; s < 7; s++)
//			std::cout << inital << i << endSqBrkt << LightProperties[s] << std::endl;
//		i++;
//	}
//}