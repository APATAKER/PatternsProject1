#include"cPirate.h"

cPirate::cPirate()
{
	this->size = 1.0f;
}

cPirate::~cPirate()
{
}
//
//void cPirate::setGameObject(iObject* pTheGO) 
//{
//	this->pTheGO = pTheGO;
//	this->pTheGO->setScale(this->size);
//
//	return;
//}
//iObject* cPirate::getGameObject()
//{
//	return this->pTheGO;
//}
